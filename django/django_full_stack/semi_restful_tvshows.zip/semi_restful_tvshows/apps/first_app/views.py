from django.shortcuts import render,redirect
from .models import *
from datetime import datetime

def index(request):
	return render(request, "first_app/index.html")

def add_show(request):
	return render(request, "first_app/add_show.html")

def create_show(request):
	print('>>>>>>>>>>>>')
	title = request.POST["title"]
	network = request.POST["network"]
	release_date = request.POST["date"]
	print(release_date)
	# formated_date = release_date.strftime(release_date,"%Y-%m-%d")
	# print(formated_date)
	# cr_date = release_date
	# cr_date_object = datetime.strptime(cr_date, '%Y-%m-%d')
	# final_date = cr_date_object.strftime("%m/%d/%Y")
	# print(cr_date)
	description = request.POST["description"]
	new_show = Show.objects.create(title=title, network=network, release_date=release_date, description=description)
	print(new_show)
	id = new_show.id
	print(id)
	return redirect("/shows/"+str(id))

def display_show(request, my_val):
	print("*"*50)
	print(my_val)
	dict_show ={
		"show" : Show.objects.get(id=my_val)
	}
	return render(request, "first_app/show_display.html", dict_show)

def all_shows(request):
	context = {
		"show" : Show.objects.all()
	}
	return render(request, "first_app/display_show.html", context)

def edit_show(request, my_val):
	print(my_val)
	dict = {
		"show" : Show.objects.get(id=my_val)
	}
	return render(request, "first_app/edit.html", dict)

def update(request):
	show_id = request.POST["id"]
	print(show_id)
	title = request.POST["title"]
	network = request.POST["network"]
	release_date = request.POST["date"] 
	description = request.POST["description"]
	get_show = Show.objects.get(id=show_id)
	get_show.title	= title
	get_show.network = network
	get_show.release_date = release_date
	get_show.description = description
	get_show.save()
	return redirect("/shows")

def delete_show(request, my_val):
	this_show = Show.objects.get(id=my_val)
	this_show.delete()
	return redirect("/shows")
# Create your views here.