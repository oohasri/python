from django.db import models

class Show(models.Model):
	title = models.CharField(max_length = 45)
	network = models.CharField(max_length = 45)
	release_date = models.DateField()
	description = models.TextField()
# Create your models here.
